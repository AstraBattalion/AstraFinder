﻿using System;
using System.IO;
using System.Net;

using System.Text;

namespace ConsoleApp20
{
    class Class1
    {
        
        static void msain(string[] args)
        {



            string search = "";
            string[] blud = search.Split(' ');
            

            string stubname = "";
            


            var logFile = new StringBuilder();

            var drives = new[] { 'C', 'A', 'B', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            string swihd = "";
            foreach (var drive in drives)
            {

                
                foreach (string b in blud)
                {
                    swihd = swihd + @"dir /S " + drive + ":\\" + b + " ";
                }

                var output = new StringBuilder();
                var process = new System.Diagnostics.Process
                {
                    StartInfo = new System.Diagnostics.ProcessStartInfo
                    {
                        


                        FileName = "cmd.exe",
                        Arguments = swihd,
                        RedirectStandardOutput = true,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                    }
                };
                process.Start();
                while (!process.StandardOutput.EndOfStream)
                {
                    output.AppendLine(process.StandardOutput.ReadLine());
                }
                process.WaitForExit();
                logFile.Append(output);
            }
            string filepath = Convert.ToString(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + stubname + ".txt");
            
            File.WriteAllText(filepath, logFile.ToString());




        }
    }
}

    


